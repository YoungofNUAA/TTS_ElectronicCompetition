import winsound


ppp = winsound.PlaySound(None,winsound.SND_NODEFAULT)
China_wav = r'F:\APP_Text2Speech\cn0001_0.wav'
English_wav = r'F:\APP_Text2Speech\en0001_0.wav'

def playmusicChina():
    global ppp
    print('播放')
    ppp = winsound.PlaySound(China_wav,winsound.SND_ALIAS)

def playmusicEnglish():
    global ppp
    print('播放')
    ppp = winsound.PlaySound(English_wav,winsound.SND_ALIAS)
