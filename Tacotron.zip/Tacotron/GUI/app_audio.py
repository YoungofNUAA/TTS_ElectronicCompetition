import numpy as np
from scipy.io import wavfile
import wave
import matplotlib.pylab as plt
import os

def get_params(root):
    files = os.listdir(root)
    for fname in files:
        if fname.endswith('.wav'):
            file_path = os.path.join(root,fname)
            f = wave.open(file_path,'rb')
            #准备绘制时域参数
            sampling_freq,audio_ori = wavfile.read(file_path)
            #准备绘制频域参数
            params = f.getparams()
            nchannels, sampwidth, framerate, nframes = params[:4]
            break
    return sampling_freq,audio_ori,nchannels,sampwidth,framerate,nframes,f

#绘制语音时域波形
def plot_time(root):
    sampling_freq, audio_ori, nchannels, sampwidth, framerate, nframes ,f= get_params(root)
    x_values = np.arange(0, len(audio_ori), 1) / float(sampling_freq)
    audio_ori = audio_ori*1.0/max(abs(audio_ori))
    plt.figure(1)
    plt.plot(x_values, audio_ori, color='blue')
    plt.xlabel('Time (ms)')
    plt.ylabel('Amplitude')
    plt.title('Audio signal')
    plt.savefig(root+'/time.png')
#绘制语音频域波形
def plot_freq(root):
    sampling_freq, audio_ori, nchannels, sampwidth, framerate, nframes, f = get_params(root)
    strData = f.readframes(nframes)
    wavaData = np.fromstring(strData,dtype=np.int16)
    wavaData = wavaData * 1.0/max(abs(wavaData))
    wavaData = np.reshape(wavaData,[nframes,nchannels]).T
    f.close()
    plt.figure(2)
    plt.specgram(wavaData[0],Fs = framerate,scale_by_freq=True,sides='default')
    plt.ylabel('Frequency')
    plt.xlabel('Time(s)')
    plt.savefig(root+'/fre.png')




