import os
import argparse
from flask import Flask, request, json, make_response, send_from_directory
from pypinyin import pinyin, Style

from en.synthesizer import Synthesizer as Synthesizer_en
from cn.synthesizer import Synthesizer as Synthesizer_cn
from en.util import audio as audio_en
from cn.util import audio as audio_cn


synthesizer_cn = Synthesizer_cn()

def load_model_cn():
    if not synthesizer_cn.isModelLoaded:
        synthesizer_cn.load('CN')
        synthesizer_cn.isModelLoaded = True
    return 'TTS engine is loaded successfully!'

def text2speech_cn(text):
    type = 'CN'
    text_contents = [text]
    wav_files = []

    for i, text in enumerate(text_contents):
        temp_filename = '%s_%d.wav' % ("cn0001", i)
        print('Synthesizing: %s' % temp_filename)
        with open(temp_filename, 'wb') as f:
            pinyin_list = pinyin(text, style=Style.TONE3)
            text = ''
            for py in pinyin_list:
                if not py[0][-1].isdigit():
                    py[0] = py[0] + '5'
                text = text + py[0] + ' '
            text.rstrip()
            print(text)
            wav_out = synthesizer_cn.synthesize(text, type)
            f.write(wav_out)
            wav_files.append(f)
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--words',default='南京航空航天大大学电子信息工程学院', help='default to say')
    args = parser.parse_args()
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    os.environ['CUDA_VISIBLE_DEVICES'] = '1'
    load_model_cn()
    text2speech_cn(args.words)
if __name__ == '__main__':
    main()



