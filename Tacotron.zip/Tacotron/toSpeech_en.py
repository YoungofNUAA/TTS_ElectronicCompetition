import os

from flask import Flask, request, json, make_response, send_from_directory
from pypinyin import pinyin, Style
import argparse
from en.synthesizer import Synthesizer as Synthesizer_en
from cn.synthesizer import Synthesizer as Synthesizer_cn
from en.util import audio as audio_en
from cn.util import audio as audio_cn

synthesizer_en = Synthesizer_en()
def load_model_en():
    if not synthesizer_en.isModelLoaded:
        synthesizer_en.load('EN')
        synthesizer_en.isModelLoaded = True
    return 'TTS engine is loaded successfully!'

def text2speech_en(text):

    text_contents = [text]
    wav_files = []

    for i, text in enumerate(text_contents):
        temp_filename = '%s_%d.wav' % ('en0001', i)
        print('Synthesizing: %s' % temp_filename)
        with open(temp_filename, 'wb') as f:
            wav_out = synthesizer_en.synthesize(text, 'EN')
            f.write(wav_out)
            wav_files.append(f)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--words',default='Hello world', help='default to say')
    args = parser.parse_args()
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    os.environ['CUDA_VISIBLE_DEVICES'] = '1'
    load_model_en()
    text2speech_en(args.words)
if __name__=="__main__":
    main()


